// Name: Minh To
// Seneca Student ID: 125526186
// Seneca email: qto@myseneca.ca    
// Date of completion: 25 Sep 19
//
// I confirm that the content of this file is created by me,
//   with the exception of the parts provided to me by my professor.

#include "LVPair.h"

namespace sdds
{
    template<class L, class V>
    LVPair<L, V>::LVPair()
    {
        keke = 0;
        val = 0;
    }
    
    template<class L, class V>
    LVPair<L, V>::LVPair(const L& aa, const V& bb)
    {
        keke = aa;
        val = bb;
    }

    template<class L, class V>
    const L& LVPair<L, V>::key() const
    {
        return keke;
    }

    template<class L, class V>
    const V& LVPair<L, V>::value() const
    {
        return val;
    }

    template<class L, class V>
    void LVPair<L, V>::display(std::ostream& os) const
    {
        os << keke << " : " << val << std::endl;
    }

    template<class L, class V>
    std::ostream& operator<<(std::ostream& os, const sdds::LVPair<L, V>& pair)
    {
        pair.display(os);
    }

}
