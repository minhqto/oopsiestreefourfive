// Name: Minh To
// Seneca Student ID: 125526186
// Seneca email: qto@myseneca.ca    
// Date of completion: 25 Sep 19
//
// I confirm that the content of this file is created by me,
//   with the exception of the parts provided to me by my professor.

#include "List.h"

namespace sdds
{
    template<class T, unsigned int s>
    size_t List<T, s>::size() const
    {
        return anyEl.size();
    }

    template<class T, unsigned int s>
    const T& List<T, s>::operator[](size_t i) const
    {
        return anyEl[i];
    }

    template<class T, unsigned int s>
    void List<T, s>::operator+=(const T& tt)
    {
        unsigned int arrSize = anyEl.size();
        if(anyEl.size() < s){
            anyEl[arrSize] = tt;
        }
    }
    
}
