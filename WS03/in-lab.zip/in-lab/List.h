// Name: Minh To
// Seneca Student ID: 125526186
// Seneca email: qto@myseneca.ca    
// Date of completion: 25 Sep 19
//
// I confirm that the content of this file is created by me,
//   with the exception of the parts provided to me by my professor.

#ifndef LIST_H
#define LIST_H

#include <iostream>
#include <string>
#include <iomanip>

namespace sdds
{
    template<class T, unsigned int maxElArr>
    
    class List
    {
        T anyEl[maxElArr];

        public: 
        
            size_t size() const;
            const T& operator[](size_t) const;
            void operator+=(const T&);
    };

}

#endif
